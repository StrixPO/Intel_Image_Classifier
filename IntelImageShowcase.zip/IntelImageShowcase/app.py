from flask import Flask, request, jsonify
import torch
from PIL import Image
from torchvision import transforms

app = Flask(__name__)

# Load your trained model
model = torch.load('../IntelImageClasification.ipynb')
model.eval()

# Define the image transformations
preprocess = transforms.Compose([
    transforms.Resize(64),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    image = Image.open(file.stream)
    image = preprocess(image).unsqueeze(0)  # Add batch dimension
    
    with torch.no_grad():
        outputs = model(image)
        _, predicted = torch.max(outputs, 1)
        class_id = predicted.item()
    
    # Map class_id to category
    categories = ['buildings', 'forest', 'glacier', 'mountain', 'sea', 'street']
    return jsonify({'category': categories[class_id]})

if __name__ == '__main__':
    app.run(debug=True)
